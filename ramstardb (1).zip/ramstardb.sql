-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2024 at 08:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ramstardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `journeys`
--

CREATE TABLE `journeys` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `start_latitude` decimal(10,7) NOT NULL,
  `start_longitude` decimal(10,7) NOT NULL,
  `end_latitude` decimal(10,7) DEFAULT NULL,
  `end_longitude` decimal(10,7) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_time` timestamp NULL DEFAULT NULL,
  `fare_amount` decimal(10,2) DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `journeys`
--

INSERT INTO `journeys` (`id`, `user_id`, `start_latitude`, `start_longitude`, `end_latitude`, `end_longitude`, `start_time`, `end_time`, `fare_amount`, `is_completed`) VALUES
(1, 72, 15.4345740, 120.8837140, 15.4349110, 120.8837340, '2024-10-26 14:08:54', '2024-10-26 14:11:32', 0.38, 1),
(2, 79, 15.4349110, 120.8837340, 15.4349110, 120.8837340, '2024-10-26 14:10:12', '2024-10-26 14:10:16', 0.00, 1),
(3, 79, 15.4349110, 120.8837340, 15.4345364, 120.8836754, '2024-10-26 14:10:33', '2024-10-26 15:17:09', 1.00, 1),
(4, 72, 15.4349110, 120.8837340, 15.4349110, 120.8837340, '2024-10-26 14:11:37', '2024-10-26 14:14:01', 0.00, 1),
(5, 72, 15.4349240, 120.8835320, 15.4349240, 120.8835320, '2024-10-26 14:15:14', '2024-10-26 14:15:28', 0.00, 1),
(6, 72, 15.4349240, 120.8835320, 15.4349240, 120.8835320, '2024-10-26 14:18:18', '2024-10-26 14:18:54', 0.00, 1),
(7, 72, 0.0000000, 0.0000000, NULL, NULL, '2024-10-26 14:19:19', NULL, NULL, 0),
(8, 69, 15.4349030, 120.8836330, 15.4349030, 120.8836330, '2024-10-26 14:21:49', '2024-10-26 14:22:10', 0.00, 1),
(9, 69, 15.4349030, 120.8836330, 15.4349030, 120.8836330, '2024-10-26 14:22:17', '2024-10-26 14:22:47', 0.00, 1),
(10, 69, 15.4349030, 120.8836330, 15.4349030, 120.8836330, '2024-10-26 14:23:48', '2024-10-26 14:24:38', 0.00, 1),
(11, 69, 15.4349030, 120.8836330, 15.4349030, 120.8836330, '2024-10-26 14:25:12', '2024-10-26 14:25:32', 0.00, 1),
(12, 69, 15.4349030, 120.8836330, 15.4349030, 120.8836330, '2024-10-26 14:26:34', '2024-10-26 14:26:49', 0.00, 1),
(13, 69, 15.5399000, 121.0811000, 15.5399000, 121.0811000, '2024-10-26 14:30:25', '2024-10-26 14:31:36', 0.00, 1),
(14, 69, 15.5399000, 121.0811000, 15.5399000, 121.0811000, '2024-10-26 14:32:04', '2024-10-26 14:33:49', 0.00, 1),
(15, 69, 15.5399000, 121.0811000, 15.1449853, 120.5887029, '2024-10-26 14:37:19', '2024-10-26 14:38:13', 343.37, 1),
(16, 69, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:38:19', '2024-10-26 14:38:39', 0.00, 1),
(17, 69, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:38:47', '2024-10-26 14:39:02', 0.00, 1),
(18, 69, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:39:48', '2024-10-26 14:40:31', 0.00, 1),
(19, 85, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:40:00', '2024-10-26 14:40:26', 0.00, 1),
(20, 69, 15.1449853, 120.5887029, 15.0837000, 120.9905000, '2024-10-26 14:40:36', '2024-10-26 14:40:58', 218.34, 1),
(21, 69, 15.0837000, 120.9905000, 15.1449853, 120.5887029, '2024-10-26 14:41:09', '2024-10-26 14:41:14', 218.34, 1),
(22, 69, 15.1449853, 120.5887029, 15.0837000, 120.9905000, '2024-10-26 14:41:26', '2024-10-26 14:41:35', 218.34, 1),
(23, 69, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:41:45', '2024-10-26 14:41:55', 0.00, 1),
(24, 69, 15.1449853, 120.5887029, 15.1449853, 120.5887029, '2024-10-26 14:42:04', '2024-10-26 14:44:02', 0.00, 1),
(25, 69, 15.1449853, 120.5887029, 15.4345176, 120.8836604, '2024-10-26 14:44:05', '2024-10-26 14:44:46', 225.69, 1),
(26, 69, 15.4345176, 120.8836604, 15.4345176, 120.8836604, '2024-10-26 14:44:50', '2024-10-26 14:44:58', 0.00, 1),
(27, 69, 15.4345176, 120.8836604, 15.4345176, 120.8836604, '2024-10-26 14:45:01', '2024-10-26 14:45:11', 0.00, 1),
(28, 69, 15.4345176, 120.8836604, 15.4345176, 120.8836604, '2024-10-26 14:45:14', '2024-10-26 14:45:47', 0.00, 1),
(29, 69, 15.4345176, 120.8836604, 15.0837000, 120.9905000, '2024-10-26 14:45:51', '2024-10-26 14:46:17', 203.29, 1),
(30, 69, 15.0837000, 120.9905000, 15.0837000, 120.9905000, '2024-10-26 14:46:55', '2024-10-26 14:47:05', 0.00, 1),
(31, 69, 15.0837000, 120.9905000, 15.1449853, 120.5887029, '2024-10-26 14:47:10', '2024-10-26 14:47:15', 218.34, 1),
(32, 69, 15.4345056, 120.8836765, 15.4345056, 120.8836765, '2024-10-26 14:51:51', '2024-10-26 14:52:10', 0.00, 1),
(33, 69, 15.1449853, 120.5887029, 15.4345367, 120.8836741, '2024-10-26 15:13:07', '2024-10-26 15:16:56', 225.70, 1),
(34, 85, 0.0000000, 0.0000000, NULL, NULL, '2024-10-26 15:14:35', NULL, NULL, 0),
(35, 69, 15.4345364, 120.8836754, 15.4345364, 120.8836754, '2024-10-26 15:17:00', '2024-10-26 15:17:22', 1.00, 1),
(36, 79, 15.4345364, 120.8836754, 15.4345364, 120.8836754, '2024-10-26 15:17:18', '2024-10-26 15:17:26', 1.00, 1),
(37, 69, 15.4345364, 120.8836754, 15.4345377, 120.8836832, '2024-10-26 15:17:29', '2024-10-26 15:18:08', 1.00, 1),
(38, 79, 15.4349240, 120.8835320, 15.4345377, 120.8836832, '2024-10-26 15:17:56', '2024-10-26 15:18:01', 1.00, 1),
(39, 79, 15.4349110, 120.8837340, 15.4349110, 120.8837340, '2024-10-26 15:24:26', '2024-10-26 15:24:32', 1.00, 1),
(40, 79, 15.4349110, 120.8837340, 15.4349110, 120.8837340, '2024-10-26 16:49:36', '2024-10-26 16:49:41', 1.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `revenue`
--

CREATE TABLE `revenue` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_type` enum('debit','credit') NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `account_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `revenue`
--

INSERT INTO `revenue` (`id`, `user_id`, `amount`, `transaction_type`, `transaction_date`, `account_number`) VALUES
(1, 79, 0.00, 'debit', '2024-10-26 14:10:16', ''),
(2, 72, 0.38, 'debit', '2024-10-26 14:11:32', ''),
(3, 72, 0.00, 'debit', '2024-10-26 14:14:01', ''),
(4, 72, 0.00, 'debit', '2024-10-26 14:15:28', ''),
(5, 72, 0.00, 'debit', '2024-10-26 14:18:54', ''),
(6, 69, 0.00, 'debit', '2024-10-26 14:22:10', ''),
(7, 69, 0.00, 'debit', '2024-10-26 14:22:47', ''),
(8, 69, 0.00, 'debit', '2024-10-26 14:24:38', ''),
(9, 69, 0.00, 'debit', '2024-10-26 14:25:32', ''),
(10, 69, 0.00, 'debit', '2024-10-26 14:26:49', ''),
(11, 69, 0.00, 'debit', '2024-10-26 14:31:37', ''),
(12, 69, 0.00, 'debit', '2024-10-26 14:33:49', ''),
(13, 69, 343.37, 'debit', '2024-10-26 14:38:13', ''),
(14, 69, 0.00, 'debit', '2024-10-26 14:38:39', ''),
(15, 69, 0.00, 'debit', '2024-10-26 14:39:03', ''),
(16, 85, 0.00, 'debit', '2024-10-26 14:40:26', ''),
(17, 69, 0.00, 'debit', '2024-10-26 14:40:31', ''),
(18, 69, 218.34, 'debit', '2024-10-26 14:40:58', ''),
(19, 69, 218.34, 'debit', '2024-10-26 14:41:14', ''),
(20, 69, 218.34, 'debit', '2024-10-26 14:41:36', ''),
(21, 69, 0.00, 'debit', '2024-10-26 14:41:55', ''),
(22, 69, 0.00, 'debit', '2024-10-26 14:44:02', ''),
(23, 69, 225.69, 'debit', '2024-10-26 14:44:46', ''),
(24, 69, 0.00, 'debit', '2024-10-26 14:44:58', ''),
(25, 69, 0.00, 'debit', '2024-10-26 14:45:11', ''),
(26, 69, 0.00, 'debit', '2024-10-26 14:45:47', ''),
(27, 69, 203.29, 'debit', '2024-10-26 14:46:17', ''),
(28, 69, 0.00, 'debit', '2024-10-26 14:47:06', ''),
(29, 69, 218.34, 'debit', '2024-10-26 14:47:15', ''),
(30, 69, 0.00, 'debit', '2024-10-26 14:52:10', ''),
(31, 69, 225.70, 'debit', '2024-10-26 15:16:56', ''),
(32, 79, 1.00, 'debit', '2024-10-26 15:17:09', ''),
(33, 69, 1.00, 'debit', '2024-10-26 15:17:22', ''),
(34, 79, 1.00, 'debit', '2024-10-26 15:17:26', ''),
(35, 79, 1.00, 'debit', '2024-10-26 15:18:01', ''),
(36, 69, 1.00, 'debit', '2024-10-26 15:18:08', ''),
(37, 79, 1.00, 'debit', '2024-10-26 15:24:32', ''),
(38, 79, 1.00, 'debit', '2024-10-26 16:49:41', '');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_number` varchar(250) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_type` enum('Load','Deduct') NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `account_number`, `amount`, `transaction_type`, `transaction_date`) VALUES
(8, 85, '0013442974', 100.00, 'Load', '2024-10-26 17:55:15'),
(10, 85, '0013442974', 100.00, 'Load', '2024-10-26 17:58:14'),
(11, 85, '0013442974', 100.00, 'Load', '2024-10-26 17:58:33'),
(12, 85, '0013442974', 100.00, 'Load', '2024-10-26 17:59:56'),
(13, 79, '0013389623', 100.00, 'Load', '2024-10-26 18:00:52');

-- --------------------------------------------------------

--
-- Table structure for table `useracc`
--

CREATE TABLE `useracc` (
  `id` int(11) UNSIGNED NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `birthday` date NOT NULL,
  `age` int(11) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `email` varchar(100) NOT NULL,
  `contactnumber` varchar(15) NOT NULL,
  `province_id` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `barangay_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `role` enum('User','Admin','Cashier') DEFAULT 'User',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_activated` tinyint(1) DEFAULT 0,
  `id_type` varchar(50) NOT NULL,
  `id_file` varchar(255) NOT NULL,
  `points` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useracc`
--

INSERT INTO `useracc` (`id`, `account_number`, `firstname`, `profile_picture`, `lastname`, `middlename`, `suffix`, `birthday`, `age`, `gender`, `email`, `contactnumber`, `province_id`, `municipality_id`, `barangay_id`, `address`, `password`, `balance`, `role`, `created_at`, `is_activated`, `id_type`, `id_file`, `points`) VALUES
(47, '0013442973', 'LynMarie', NULL, 'Mapoy', 'wrqwerrq', '', '2017-10-02', 7, 'Male', 'lynmariemapoy1@gmail.com', '991712578', 56, 1029, 18731, '123', '$2y$10$kxpCU1mPx1zMSWQnxum7b.VWYulJPKLP2lwdsYLwWg7BdOrIuzHWq', 12545.00, 'User', '2024-10-16 15:44:49', 0, '', '', 0.00),
(61, '0013412479', 'Bitoy', NULL, 'V', 'qwertt', 'Jr', '2017-10-01', 7, 'Male', 'abrahamflor3s29@gmail.com', '630991712578', 56, 1014, 18315, '123', '087cf0e1df4b6eeac6fc6f275edcc88c', NULL, 'User', '2024-10-19 15:49:04', 0, '', '', 0.00),
(69, '0012258965', 'archie', NULL, 'vicente', 'diaz', '', '2003-06-29', 21, 'Male', 'vicentearchiediaz29@gmail.com', '+631236549871', 56, 1029, 18709, '3', '74', 9772.30, 'User', '2024-10-20 15:37:01', 1, '', '', 0.00),
(72, '0012245507', 'LynMarie', NULL, 'Mapoy', 'asd', 'Jr', '2017-10-18', 7, 'Female', 'lynmariemapoy7@gmail.com', '631234568765', 4, 57, 2039, 'rg', 'e13f22d01e7795e453c92fa9bc86e2d3', 1899.62, 'User', '2024-10-20 16:05:36', 0, '', '', 0.00),
(79, '0013389623', 'James Andrew', NULL, 'Beley', 'Adriano', '', '2002-04-07', 22, 'Male', 'jemusubeley@gmail.com', '09917127663', 56, 1029, 18731, '123', '2637a5c30af69a7bad877fdb65fbd78b', 1020.00, 'User', '2024-10-21 06:39:01', 1, '', '', 80.00),
(85, '0013442974', 'LynMarie', NULL, 'Maglalang', 'asdasd', '', '1999-06-24', 25, 'Male', 'jemusu96@gmail.com', '9168628696', 34900000, 34928000, 34928016, '123', '2637a5c30af69a7bad877fdb65fbd78b', 3100.00, 'Cashier', '2024-10-23 16:34:33', 1, '', '', 0.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `journeys`
--
ALTER TABLE `journeys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `revenue`
--
ALTER TABLE `revenue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `useracc`
--
ALTER TABLE `useracc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `account_number` (`account_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `journeys`
--
ALTER TABLE `journeys`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `revenue`
--
ALTER TABLE `revenue`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `useracc`
--
ALTER TABLE `useracc`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `journeys`
--
ALTER TABLE `journeys`
  ADD CONSTRAINT `journeys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `useracc` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `revenue`
--
ALTER TABLE `revenue`
  ADD CONSTRAINT `revenue_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `useracc` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
