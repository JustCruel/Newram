-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2024 at 11:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ramstardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `revenue`
--

CREATE TABLE `revenue` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_type` enum('debit') NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `revenue`
--

INSERT INTO `revenue` (`id`, `user_id`, `amount`, `transaction_type`, `transaction_date`) VALUES
(12, 85, 50.00, 'debit', '2024-10-24 07:48:51'),
(13, 85, 50.00, 'debit', '2024-10-24 07:49:15'),
(14, 85, 50.00, 'debit', '2024-10-24 07:49:18'),
(15, 85, 50.00, 'debit', '2024-10-24 07:49:20'),
(16, 85, 50.00, 'debit', '2024-10-24 07:51:24'),
(17, 85, 50.00, 'debit', '2024-10-24 07:51:25'),
(18, 85, 50.00, 'debit', '2024-10-24 07:51:26'),
(19, 85, 50.00, 'debit', '2024-10-24 07:51:27'),
(20, 69, 50.00, 'debit', '2024-10-24 07:51:53'),
(21, 69, 50.00, 'debit', '2024-10-24 07:51:54'),
(22, 69, 50.00, 'debit', '2024-10-24 07:51:56'),
(23, 69, 50.00, 'debit', '2024-10-24 07:51:57'),
(24, 69, 50.00, 'debit', '2024-10-24 07:51:59'),
(25, 69, 50.00, 'debit', '2024-10-24 07:52:00'),
(26, 69, 50.00, 'debit', '2024-10-24 07:52:02'),
(27, 69, 50.00, 'debit', '2024-10-24 07:52:04'),
(28, 69, 50.00, 'debit', '2024-10-24 07:52:05'),
(29, 69, 50.00, 'debit', '2024-10-24 07:52:05'),
(30, 69, 50.00, 'debit', '2024-10-24 07:52:06'),
(31, 69, 50.00, 'debit', '2024-10-24 07:52:07'),
(32, 69, 50.00, 'debit', '2024-10-24 07:52:11'),
(33, 69, 50.00, 'debit', '2024-10-24 07:52:12'),
(34, 69, 50.00, 'debit', '2024-10-24 07:52:14'),
(35, 69, 50.00, 'debit', '2024-10-24 07:52:16'),
(36, 69, 50.00, 'debit', '2024-10-24 07:52:18'),
(37, 69, 50.00, 'debit', '2024-10-24 07:52:20'),
(38, 69, 50.00, 'debit', '2024-10-24 07:52:22'),
(39, 69, 50.00, 'debit', '2024-10-24 07:52:24'),
(40, 69, 50.00, 'debit', '2024-10-24 07:54:50'),
(41, 69, 50.00, 'debit', '2024-10-24 07:54:55'),
(42, 85, 50.00, 'debit', '2024-10-24 07:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_number` varchar(250) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_type` enum('Load','Deduct') NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `account_number`, `amount`, `transaction_type`, `transaction_date`) VALUES
(10, 72, '', 1000.00, 'Load', '2024-10-20 16:10:49'),
(11, 72, '', 250.00, 'Load', '2024-10-20 16:22:28'),
(12, 72, '', 100.00, 'Load', '2024-10-21 05:39:10'),
(13, 72, '', 100.00, 'Load', '2024-10-21 05:41:17'),
(14, 72, '', 100.00, 'Load', '2024-10-21 05:42:13'),
(16, 61, '', 1000.00, 'Load', '2024-10-24 06:53:21'),
(17, 61, '', 1000.00, 'Load', '2024-10-24 06:53:54'),
(18, 85, '', 200.00, 'Load', '2024-10-24 07:06:02'),
(19, 85, '', 200.00, 'Load', '2024-10-24 07:06:05'),
(20, 69, '', 1000.00, 'Load', '2024-10-24 07:51:42'),
(21, 69, '', 1000.00, 'Load', '2024-10-24 07:54:43'),
(22, 85, '', 1000.00, 'Load', '2024-10-24 07:57:53'),
(23, 85, '', 100.00, 'Load', '2024-10-24 10:28:58'),
(24, 85, '', 50.00, 'Load', '2024-10-24 10:30:21'),
(25, 85, '', 50.00, 'Load', '2024-10-24 10:30:27'),
(26, 85, '', 50.00, 'Load', '2024-10-24 10:30:30'),
(27, 85, '', 50.00, 'Load', '2024-10-24 10:32:01'),
(28, 85, '', 50.00, 'Load', '2024-10-24 10:32:15'),
(29, 85, '', 50.00, 'Load', '2024-10-24 10:32:51'),
(30, 85, '', 50.00, 'Load', '2024-10-24 10:34:33'),
(31, 85, '', 50.00, 'Load', '2024-10-24 10:37:05'),
(32, 85, '', 50.00, 'Load', '2024-10-24 10:38:40'),
(33, 85, '', 50.00, 'Load', '2024-10-24 10:41:32'),
(34, 85, '', 50.00, 'Load', '2024-10-24 10:41:45'),
(35, 69, '', 100.00, 'Load', '2024-10-24 10:50:48'),
(36, 72, '', 50.00, 'Load', '2024-10-24 17:25:26'),
(37, 72, '', 100.00, 'Load', '2024-10-24 17:29:45'),
(38, 72, '0012245507', 50.00, 'Load', '2024-10-24 21:16:01'),
(39, 85, '0013442974', 400.00, 'Load', '2024-10-24 21:16:28');

-- --------------------------------------------------------

--
-- Table structure for table `useracc`
--

CREATE TABLE `useracc` (
  `id` int(11) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `birthday` date NOT NULL,
  `age` int(11) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `email` varchar(100) NOT NULL,
  `contactnumber` varchar(15) NOT NULL,
  `province_id` int(11) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `barangay_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `role` enum('User','Admin','Cashier') DEFAULT 'User',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_activated` tinyint(1) DEFAULT 0,
  `id_type` varchar(50) NOT NULL,
  `id_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useracc`
--

INSERT INTO `useracc` (`id`, `account_number`, `firstname`, `profile_picture`, `lastname`, `middlename`, `suffix`, `birthday`, `age`, `gender`, `email`, `contactnumber`, `province_id`, `municipality_id`, `barangay_id`, `address`, `password`, `balance`, `role`, `created_at`, `is_activated`, `id_type`, `id_file`) VALUES
(47, '0013442973', 'LynMarie', NULL, 'Mapoy', 'wrqwerrq', '', '2017-10-02', 7, 'Male', 'lynmariemapoy1@gmail.com', '991712578', 56, 1029, 18731, '123', '$2y$10$kxpCU1mPx1zMSWQnxum7b.VWYulJPKLP2lwdsYLwWg7BdOrIuzHWq', 12545.00, 'User', '2024-10-16 15:44:49', 0, '', ''),
(61, '0013412479', 'Bitoy', NULL, 'V', 'qwertt', 'Jr', '2017-10-01', 7, 'Male', 'abrahamflor3s29@gmail.com', '630991712578', 56, 1014, 18315, '123', '087cf0e1df4b6eeac6fc6f275edcc88c', NULL, 'User', '2024-10-19 15:49:04', 0, '', ''),
(69, '0012258965', 'archie', NULL, 'vicente', 'diaz', '', '2003-06-29', 21, 'Male', 'vicentearchiediaz29@gmail.com', '+631236549871', 56, 1029, 18709, '3', '74', 1100.00, '', '2024-10-20 15:37:01', 1, '', ''),
(72, '0012245507', 'LynMarie', NULL, 'Mapoy', 'asd', 'Jr', '2017-10-18', 7, 'Female', 'lynmariemapoy7@gmail.com', '631234568765', 4, 57, 2039, 'rg', 'e13f22d01e7795e453c92fa9bc86e2d3', 2000.00, 'User', '2024-10-20 16:05:36', 0, '', ''),
(79, '0013389623', 'James Andrew', NULL, 'Beley', 'Adriano', '', '2002-04-07', 22, 'Male', 'jemusubeley@gmail.com', '09917127663', 56, 1029, 18731, '123', '2637a5c30af69a7bad877fdb65fbd78b', 0.00, 'User', '2024-10-21 06:39:01', 1, '', ''),
(85, '0013442974', 'LynMarie', NULL, 'Maglalang', 'asdasd', '', '1999-06-24', 25, 'Male', 'jemusu96@gmail.com', '9168628696', 34900000, 34928000, 34928016, '123', '2637a5c30af69a7bad877fdb65fbd78b', 2000.00, 'Cashier', '2024-10-23 16:34:33', 1, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `revenue`
--
ALTER TABLE `revenue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `useracc`
--
ALTER TABLE `useracc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `account_number` (`account_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `revenue`
--
ALTER TABLE `revenue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `useracc`
--
ALTER TABLE `useracc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `revenue`
--
ALTER TABLE `revenue`
  ADD CONSTRAINT `revenue_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `useracc` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `useracc` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
